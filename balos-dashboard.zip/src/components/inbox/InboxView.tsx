'use client';

import { useState, useEffect, useTransition } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { Lead, Message } from '../../lib/types';
import { takeOverLead, handBackToAi } from '../../lib/actions/leads';
import { formatDubaiTime, formatDubaiDateTime, formatDuration } from '../../lib/date';
import { formatAED } from '../../lib/utils';
import {
  PauseCircle,
  PlayCircle,
  Bot,
  User,
  ShieldAlert,
  ArrowLeft,
  ChevronRight,
  Info,
  Clock,
  Sparkles,
  MapPin,
  Bed,
  CheckCircle2,
  AlertTriangle,
} from 'lucide-react';

interface InboxViewProps {
  initialLeads: Lead[];
  initialMessages: Record<string, Message[]>;
  initialSelectedLeadId?: string;
}

export function InboxView({
  initialLeads,
  initialMessages,
  initialSelectedLeadId,
}: InboxViewProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const queryLeadId = searchParams.get('lead');

  const [activeTab, setActiveTab] = useState<'paused' | 'all'>('paused');
  const [selectedLeadId, setSelectedLeadId] = useState<string>(
    queryLeadId || initialSelectedLeadId || initialLeads[0]?.id || ''
  );
  const [showMobileDetail, setShowMobileDetail] = useState(false);
  const [isPending, startTransition] = useTransition();
  const [actionError, setActionError] = useState<string | null>(null);

  // Auto-refresh every 15 seconds while tab is visible
  useEffect(() => {
    const interval = setInterval(() => {
      if (document.visibilityState === 'visible') {
        router.refresh();
      }
    }, 15000);
    return () => clearInterval(interval);
  }, [router]);

  // Sync with URL query parameter
  useEffect(() => {
    if (queryLeadId && queryLeadId !== selectedLeadId) {
      setSelectedLeadId(queryLeadId);
      setShowMobileDetail(true);
    }
  }, [queryLeadId, selectedLeadId]);

  // Filter and sort leads based on active tab
  const pausedLeads = initialLeads
    .filter((l) => l.ai_paused)
    .sort((a, b) => {
      const timeA = new Date(a.handoff_at || a.updated_at).getTime();
      const timeB = new Date(b.handoff_at || b.updated_at).getTime();
      return timeA - timeB; // longest waiting first (ascending)
    });

  const allLeads = [...initialLeads].sort((a, b) => {
    const timeA = new Date(a.last_lead_message_at || a.updated_at).getTime();
    const timeB = new Date(b.last_lead_message_at || b.updated_at).getTime();
    return timeB - timeA; // descending by last message
  });

  const displayedLeads = activeTab === 'paused' ? pausedLeads : allLeads;

  // Selected lead and its messages
  const selectedLead = initialLeads.find((l) => l.id === selectedLeadId) || displayedLeads[0];
  const messages = selectedLead ? initialMessages[selectedLead.id] || [] : [];

  const handleSelectLead = (id: string) => {
    setSelectedLeadId(id);
    setShowMobileDetail(true);
    setActionError(null);
  };

  const handleTakeOver = () => {
    if (!selectedLead) return;
    setActionError(null);
    startTransition(async () => {
      const res = await takeOverLead(selectedLead.id);
      if (!res.success) {
        setActionError(res.error || 'Failed to take over lead.');
      } else {
        router.refresh();
      }
    });
  };

  const handleHandBack = () => {
    if (!selectedLead) return;
    setActionError(null);
    startTransition(async () => {
      const res = await handBackToAi(selectedLead.id, selectedLead.stage);
      if (!res.success) {
        setActionError(res.error || 'Failed to hand back to AI.');
      } else {
        router.refresh();
      }
    });
  };

  return (
    <div className="bg-surface rounded-2xl border border-border shadow-sm flex flex-col h-[calc(100vh-8.5rem)] md:h-[calc(100vh-7.5rem)] overflow-hidden">
      <div className="flex-1 flex min-h-0">
        {/* Left Panel: Leads List */}
        <div
          className={`w-full md:w-80 lg:w-96 border-r border-border flex flex-col shrink-0 bg-surface ${
            showMobileDetail ? 'hidden md:flex' : 'flex'
          }`}
        >
          {/* Tabs header */}
          <div className="p-3 border-b border-border bg-surface-subtle">
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-seaglass rounded-xl border border-border/60">
              <button
                onClick={() => setActiveTab('paused')}
                className={`py-1.5 px-2 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
                  activeTab === 'paused'
                    ? 'bg-surface text-ink shadow-xs'
                    : 'text-ink-muted hover:text-ink'
                }`}
              >
                <span>Needs attention</span>
                {pausedLeads.length > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full text-[10px] font-bold bg-coral text-white">
                    {pausedLeads.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('all')}
                className={`py-1.5 px-2 rounded-lg text-xs font-semibold transition flex items-center justify-center gap-1.5 ${
                  activeTab === 'all'
                    ? 'bg-surface text-ink shadow-xs'
                    : 'text-ink-muted hover:text-ink'
                }`}
              >
                <span>All conversations</span>
                <span className="text-[10px] text-ink-faint">
                  ({allLeads.length})
                </span>
              </button>
            </div>
          </div>

          {/* List items */}
          <div className="flex-1 overflow-y-auto divide-y divide-border/50">
            {displayedLeads.length === 0 ? (
              <div className="p-8 text-center text-xs text-ink-muted">
                {activeTab === 'paused'
                  ? 'No paused leads waiting for agent action.'
                  : 'No conversations recorded yet.'}
              </div>
            ) : (
              displayedLeads.map((lead) => {
                const isSelected = selectedLead?.id === lead.id;
                const leadMsgs = initialMessages[lead.id] || [];
                const lastMsg = leadMsgs[leadMsgs.length - 1];

                return (
                  <div
                    key={lead.id}
                    onClick={() => handleSelectLead(lead.id)}
                    className={`p-3.5 cursor-pointer transition flex items-start justify-between gap-3 text-left ${
                      isSelected
                        ? 'bg-creek-subtle/80 border-l-4 border-l-creek'
                        : 'hover:bg-seaglass/40'
                    }`}
                  >
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2 mb-0.5">
                        <span className="font-semibold text-xs text-ink truncate">
                          {lead.full_name && lead.full_name !== '.'
                            ? lead.full_name
                            : 'Direct WhatsApp Lead'}
                        </span>
                        {lead.ai_paused && (
                          <span className="text-[10px] px-1.5 py-0.2 rounded bg-coral-light text-coral font-medium shrink-0">
                            Paused
                          </span>
                        )}
                      </div>

                      <p className="text-[11px] text-ink-muted truncate mb-1">
                        {lead.e164_phone || lead.whatsapp_id}
                      </p>

                      {lastMsg && (
                        <p className="text-xs text-ink-soft line-clamp-1">
                          {lastMsg.sender === 'AI' ? 'AI: ' : ''}
                          {lastMsg.content}
                        </p>
                      )}

                      {lead.ai_paused && lead.handoff_reason && (
                        <p className="text-[10px] text-coral mt-1 line-clamp-1 italic">
                          "{lead.handoff_reason}"
                        </p>
                      )}
                    </div>

                    <div className="text-right shrink-0">
                      <span className="text-[10px] text-ink-muted block">
                        {lead.ai_paused && lead.handoff_at
                          ? formatDuration(lead.handoff_at)
                          : formatDubaiTime(lead.last_lead_message_at || lead.updated_at)}
                      </span>
                      <span className="mt-1 inline-block text-[9px] font-medium uppercase px-1.5 py-0.5 rounded bg-seaglass text-ink-muted">
                        {lead.stage}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* Right Panel: Chat Thread & Dossier */}
        <div
          className={`flex-1 flex flex-col min-w-0 bg-seaglass/20 ${
            !showMobileDetail ? 'hidden md:flex' : 'flex'
          }`}
        >
          {selectedLead ? (
            <>
              {/* Thread Header */}
              <div className="h-16 px-4 md:px-6 border-b border-border bg-surface flex items-center justify-between gap-3 shrink-0">
                <div className="flex items-center gap-3 min-w-0">
                  <button
                    onClick={() => setShowMobileDetail(false)}
                    className="md:hidden p-1.5 -ml-1 text-ink-muted hover:text-ink rounded-lg hover:bg-seaglass"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </button>

                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h2 className="text-sm font-bold font-heading text-ink truncate">
                        {selectedLead.full_name && selectedLead.full_name !== '.'
                          ? selectedLead.full_name
                          : 'Direct WhatsApp Lead'}
                      </h2>
                      <span
                        className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                          selectedLead.ai_paused
                            ? 'bg-coral-light text-coral'
                            : 'bg-creek-light text-creek'
                        }`}
                      >
                        {selectedLead.ai_paused ? 'AI paused' : 'AI active'}
                      </span>
                    </div>
                    <p className="text-xs text-ink-muted truncate">
                      {selectedLead.e164_phone || selectedLead.whatsapp_id} • Stage: {selectedLead.stage}
                    </p>
                  </div>
                </div>

                {/* Take over / Hand back action buttons */}
                <div className="flex items-center gap-2 shrink-0">
                  {selectedLead.ai_paused ? (
                    <button
                      onClick={handleHandBack}
                      disabled={isPending}
                      className="px-3 py-1.5 rounded-lg bg-creek hover:bg-creek-hover text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition disabled:opacity-60"
                    >
                      <PlayCircle className="w-4 h-4" />
                      <span>Hand back to AI</span>
                    </button>
                  ) : (
                    <button
                      onClick={handleTakeOver}
                      disabled={isPending}
                      className="px-3 py-1.5 rounded-lg bg-coral hover:bg-coral-hover text-white text-xs font-semibold flex items-center gap-1.5 shadow-sm transition disabled:opacity-60"
                    >
                      <PauseCircle className="w-4 h-4" />
                      <span>Take over</span>
                    </button>
                  )}
                </div>
              </div>

              {actionError && (
                <div className="px-4 py-2 bg-coral-light border-b border-coral/30 text-coral text-xs">
                  {actionError}
                </div>
              )}

              {/* Main Middle Area: Thread + Right Lead Intelligence Panel */}
              <div className="flex-1 flex min-h-0">
                {/* Message stream */}
                <div className="flex-1 flex flex-col min-h-0 bg-surface/50">
                  <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-4">
                    {messages.length === 0 ? (
                      <div className="h-full flex items-center justify-center text-xs text-ink-muted">
                        No messages in this conversation yet.
                      </div>
                    ) : (
                      messages.map((msg) => {
                        const isLead = msg.sender === 'LEAD';
                        const isAI = msg.sender === 'AI';
                        const isAgent = msg.sender === 'HUMAN_AGENT';

                        return (
                          <div
                            key={msg.id}
                            className={`flex flex-col ${
                              isLead ? 'items-start' : 'items-end'
                            }`}
                          >
                            <div className="flex items-center gap-1 text-[10px] text-ink-faint mb-1 px-1">
                              {isAI && (
                                <span className="inline-flex items-center gap-0.5 text-creek font-medium">
                                  <Bot className="w-3 h-3" /> Balos AI
                                </span>
                              )}
                              {isAgent && (
                                <span className="inline-flex items-center gap-0.5 text-ink-muted font-medium">
                                  <User className="w-3 h-3" /> Human agent
                                </span>
                              )}
                              {isLead && (
                                <span className="text-ink-muted font-medium">
                                  {selectedLead.full_name || 'Lead'}
                                </span>
                              )}
                              <span>•</span>
                              <span>{formatDubaiTime(msg.created_at)}</span>
                            </div>

                            <div
                              className={`max-w-[85%] sm:max-w-md p-3.5 rounded-2xl text-xs leading-relaxed whitespace-pre-wrap ${
                                isAI
                                  ? 'bg-creek-light/70 text-ink border border-creek/20 rounded-tr-xs'
                                  : isAgent
                                  ? 'bg-surface-pure text-ink border border-border shadow-xs rounded-tr-xs'
                                  : 'bg-seaglass text-ink border border-border/70 rounded-tl-xs'
                              }`}
                            >
                              {msg.content}
                            </div>
                          </div>
                        );
                      })
                    )}
                  </div>

                  {/* V1 WhatsApp Reply Notice (No reply box in v1) */}
                  <div className="p-3.5 bg-surface border-t border-border flex items-center justify-between text-xs text-ink-muted">
                    <div className="flex items-center gap-2">
                      <Info className="w-4 h-4 text-creek shrink-0" />
                      <span>
                        Reply to this lead from your WhatsApp.
                      </span>
                    </div>
                    {selectedLead.e164_phone && (
                      <a
                        href={`https://wa.me/${selectedLead.e164_phone.replace(/[^0-9]/g, '')}`}
                        target="_blank"
                        rel="noreferrer"
                        className="text-xs font-semibold text-creek hover:underline shrink-0"
                      >
                        Open WhatsApp
                      </a>
                    )}
                  </div>
                </div>

                {/* Right Lead Details Panel (Desktop) */}
                <div className="hidden lg:flex w-72 border-l border-border bg-surface p-4 flex-col overflow-y-auto space-y-4 shrink-0 text-xs">
                  <div>
                    <h3 className="text-xs font-bold font-heading text-ink mb-2">
                      Lead dossier
                    </h3>
                    <div className="p-3 bg-surface-subtle rounded-xl border border-border space-y-2">
                      <div className="flex justify-between">
                        <span className="text-ink-muted">Score</span>
                        <span className="font-bold text-creek">
                          {selectedLead.lead_score ?? '—'}/100
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-ink-muted">Temperature</span>
                        <span className="font-semibold text-ink">
                          {selectedLead.temperature || '—'}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-ink-muted">Budget</span>
                        <span className="font-semibold text-ink">
                          {selectedLead.budget_aed_min || selectedLead.budget_aed_max
                            ? `${formatAED(selectedLead.budget_aed_min)} - ${formatAED(selectedLead.budget_aed_max)}`
                            : 'Flexible'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {selectedLead.target_communities && selectedLead.target_communities.length > 0 && (
                    <div>
                      <h4 className="text-[11px] font-semibold text-ink mb-1.5 flex items-center gap-1">
                        <MapPin className="w-3.5 h-3.5 text-creek" />
                        Target communities
                      </h4>
                      <div className="flex flex-wrap gap-1.5">
                        {selectedLead.target_communities.map((c) => (
                          <span
                            key={c}
                            className="px-2 py-0.5 rounded-md bg-seaglass text-[11px] text-ink font-medium"
                          >
                            {c}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  <div>
                    <h4 className="text-[11px] font-semibold text-ink mb-1.5 flex items-center gap-1">
                      <Bed className="w-3.5 h-3.5 text-creek" />
                      Preferences
                    </h4>
                    <div className="space-y-1 text-ink-muted">
                      <p>
                        Bedrooms:{' '}
                        <span className="text-ink font-medium">
                          {selectedLead.min_bedrooms ?? 'Any'} - {selectedLead.max_bedrooms ?? 'Any'}
                        </span>
                      </p>
                      <p>
                        Category:{' '}
                        <span className="text-ink font-medium">
                          {selectedLead.target_category || 'Any'}
                        </span>
                      </p>
                      <p>
                        Timeline:{' '}
                        <span className="text-ink font-medium">
                          {selectedLead.timeline || 'Immediate'}
                        </span>
                      </p>
                    </div>
                  </div>

                  {selectedLead.handoff_reason && (
                    <div>
                      <h4 className="text-[11px] font-semibold text-coral mb-1 flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        Handoff reason
                      </h4>
                      <p className="p-2.5 rounded-lg bg-coral-light text-coral text-[11px] leading-relaxed">
                        {selectedLead.handoff_reason}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </>
          ) : (
            <div className="h-full flex items-center justify-center text-xs text-ink-muted">
              Select a conversation to view messages.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
