import Link from 'next/link';
import { Lead } from '../../lib/types';
import { formatDuration } from '../../lib/date';
import { ArrowRight, UserCheck, Clock } from 'lucide-react';

interface NeedsYouSectionProps {
  pausedLeads: Lead[];
}

export function NeedsYouSection({ pausedLeads }: NeedsYouSectionProps) {
  return (
    <div className="bg-surface rounded-2xl border border-border p-5 shadow-sm flex flex-col h-full">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-coral animate-pulse" />
          <h2 className="text-sm font-semibold text-ink font-heading">
            Needs you
          </h2>
          <span className="text-xs px-2 py-0.5 rounded-full bg-coral-light text-coral font-medium">
            {pausedLeads.length} {pausedLeads.length === 1 ? 'lead' : 'leads'}
          </span>
        </div>
        <Link
          href="/inbox"
          className="text-xs font-medium text-creek hover:underline flex items-center gap-1"
        >
          View all
          <ArrowRight className="w-3 h-3" />
        </Link>
      </div>

      {pausedLeads.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center py-8 text-center px-4">
          <div className="w-10 h-10 rounded-full bg-seaglass flex items-center justify-center text-creek mb-2">
            <UserCheck className="w-5 h-5" />
          </div>
          <p className="text-xs font-medium text-ink">All leads handled by AI</p>
          <p className="text-[11px] text-ink-muted mt-0.5 max-w-xs">
            When a client asks for a human agent or needs negotiation, they will appear here.
          </p>
        </div>
      ) : (
        <div className="space-y-2.5 flex-1">
          {pausedLeads.slice(0, 5).map((lead) => {
            const waitTime = formatDuration(lead.handoff_at || lead.updated_at);
            return (
              <Link
                key={lead.id}
                href={`/inbox?lead=${lead.id}`}
                className="group block p-3 rounded-xl border border-border/70 hover:border-coral/40 hover:bg-coral-light/20 transition"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-ink truncate group-hover:text-coral transition">
                      {lead.full_name && lead.full_name !== '.' ? lead.full_name : 'Direct WhatsApp Lead'}
                    </p>
                    <p className="text-[11px] text-ink-muted truncate">
                      {lead.e164_phone || lead.whatsapp_id || 'No phone'}
                    </p>
                  </div>
                  <div className="flex items-center gap-1 text-[11px] font-medium text-coral shrink-0 bg-coral-light px-2 py-0.5 rounded-full">
                    <Clock className="w-3 h-3" />
                    <span>{waitTime}</span>
                  </div>
                </div>

                {lead.handoff_reason && (
                  <p className="text-[11px] text-ink-muted mt-2 line-clamp-1 italic bg-surface-subtle px-2 py-1 rounded">
                    "{lead.handoff_reason}"
                  </p>
                )}
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
