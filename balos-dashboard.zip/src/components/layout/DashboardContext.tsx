'use client';

import React, { createContext, useContext } from 'react';
import { Agent } from '../../lib/types';

interface DashboardContextType {
  user: {
    id: string;
    email?: string;
  };
  isAdmin: boolean;
  agent?: Agent | null;
}

const DashboardContext = createContext<DashboardContextType>({
  user: { id: '' },
  isAdmin: false,
  agent: null,
});

export function DashboardProvider({
  children,
  value,
}: {
  children: React.ReactNode;
  value: DashboardContextType;
}) {
  return (
    <DashboardContext.Provider value={value}>
      {children}
    </DashboardContext.Provider>
  );
}

export function useDashboard() {
  return useContext(DashboardContext);
}
