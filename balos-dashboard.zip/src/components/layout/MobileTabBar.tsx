'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import {
  LayoutDashboard,
  MessageSquare,
  Users,
  Calendar,
  Building2,
} from 'lucide-react';

export function MobileTabBar() {
  const pathname = usePathname();

  const tabs = [
    { label: 'Overview', href: '/', icon: LayoutDashboard },
    { label: 'Inbox', href: '/inbox', icon: MessageSquare },
    { label: 'Leads', href: '/leads', icon: Users },
    { label: 'Viewings', href: '/viewings', icon: Calendar },
    { label: 'Properties', href: '/properties', icon: Building2 },
  ];

  const isActive = (href: string) => {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  };

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 h-16 bg-surface/95 backdrop-blur-md border-t border-border px-2 flex items-center justify-around">
      {tabs.map((tab) => {
        const active = isActive(tab.href);
        const Icon = tab.icon;
        return (
          <Link
            key={tab.href}
            href={tab.href}
            className={`flex flex-col items-center justify-center py-1 px-2.5 rounded-lg transition ${
              active
                ? 'text-creek'
                : 'text-ink-muted hover:text-ink'
            }`}
          >
            <Icon className={`w-5 h-5 mb-0.5 ${active ? 'text-creek stroke-[2.2]' : 'text-ink-soft'}`} />
            <span className={`text-[11px] font-medium leading-none ${active ? 'font-semibold text-creek' : ''}`}>
              {tab.label}
            </span>
          </Link>
        );
      })}
    </nav>
  );
}
