'use server';

import { createClient } from '../supabase/server';
import { revalidatePath } from 'next/cache';

/**
 * Take over lead from AI:
 * ai_paused = true, handoff_at = now(). Leave stage alone.
 * Never edit any other lead field.
 */
export async function takeOverLead(leadId: string) {
  const supabase = createClient();

  const { error } = await supabase
    .from('leads')
    .update({
      ai_paused: true,
      handoff_at: new Date().toISOString(),
    })
    .eq('id', leadId);

  if (error) {
    return { success: false, error: error.message };
  }

  revalidatePath('/inbox');
  revalidatePath('/');
  revalidatePath('/leads');
  return { success: true };
}

/**
 * Hand lead back to AI:
 * ai_paused = false. Only if stage = 'HANDOFF_TO_AGENT', set stage = 'ENGAGED'.
 * Never edit any other lead field.
 */
export async function handBackToAi(leadId: string, currentStage?: string) {
  const supabase = createClient();

  const updatePayload: { ai_paused: boolean; stage?: string } = {
    ai_paused: false,
  };

  if (currentStage === 'HANDOFF_TO_AGENT') {
    updatePayload.stage = 'ENGAGED';
  }

  const { error } = await supabase
    .from('leads')
    .update(updatePayload)
    .eq('id', leadId);

  if (error) {
    return { success: false, error: error.message };
  }

  revalidatePath('/inbox');
  revalidatePath('/');
  revalidatePath('/leads');
  return { success: true };
}
