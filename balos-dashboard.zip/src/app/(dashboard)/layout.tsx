import { redirect } from 'next/navigation';
import { createClient } from '../../lib/supabase/server';
import { DashboardProvider } from '../../components/layout/DashboardContext';
import { Sidebar } from '../../components/layout/Sidebar';
import { Header } from '../../components/layout/Header';
import { MobileTabBar } from '../../components/layout/MobileTabBar';

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const supabase = createClient();

  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) {
    redirect('/login');
  }

  // Hard Rule 2: Call RPC is_dashboard_user()
  const { data: isUser, error: userError } = await supabase.rpc('is_dashboard_user');

  if (userError || !isUser) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 bg-seaglass text-ink">
        <div className="bg-surface p-8 rounded-xl border border-border max-w-md text-center shadow-sm">
          <p className="text-base text-ink font-medium">
            Your account isn't set up for this dashboard. Ask your admin.
          </p>
        </div>
      </div>
    );
  }

  // Hard Rule 3: Call RPC is_dashboard_admin()
  const { data: isAdminData } = await supabase.rpc('is_dashboard_admin');
  const isAdmin = Boolean(isAdminData);

  // Fetch agent details for UI profile display
  const { data: agentData } = await supabase
    .from('agents')
    .select('*')
    .eq('email', user.email)
    .maybeSingle();

  return (
    <DashboardProvider
      value={{
        user: { id: user.id, email: user.email },
        isAdmin,
        agent: agentData || null,
      }}
    >
      <div className="min-h-screen flex bg-seaglass text-ink">
        {/* Desktop left rail */}
        <Sidebar />

        {/* Main content area */}
        <div className="flex-1 flex flex-col min-w-0 pb-20 md:pb-6">
          <Header />
          <main className="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto">
            {children}
          </main>
        </div>

        {/* Mobile bottom tab bar */}
        <MobileTabBar />
      </div>
    </DashboardProvider>
  );
}
