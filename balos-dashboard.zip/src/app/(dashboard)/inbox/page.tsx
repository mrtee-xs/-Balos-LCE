import { createClient } from '../../../lib/supabase/server';
import { InboxView } from '../../../components/inbox/InboxView';
import { Lead, Message } from '../../../lib/types';

export const revalidate = 0; // dynamic

export default async function InboxPage({
  searchParams,
}: {
  searchParams: { lead?: string };
}) {
  const supabase = createClient();

  // Fetch leads
  const { data: leadsData } = await supabase
    .from('leads')
    .select('*')
    .order('created_at', { ascending: false });

  const leads: Lead[] = leadsData || [];

  // Fetch messages
  const { data: messagesData } = await supabase
    .from('messages')
    .select('*')
    .order('created_at', { ascending: true });

  const messages: Message[] = messagesData || [];

  // Group messages by lead_id
  const messagesByLead: Record<string, Message[]> = {};
  for (const m of messages) {
    if (!messagesByLead[m.lead_id]) {
      messagesByLead[m.lead_id] = [];
    }
    messagesByLead[m.lead_id].push(m);
  }

  return (
    <InboxView
      initialLeads={leads}
      initialMessages={messagesByLead}
      initialSelectedLeadId={searchParams?.lead}
    />
  );
}
